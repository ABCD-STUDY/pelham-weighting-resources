# ------------------------------------------------------------------------------
# First, verify that the distribution of the weights is okay
#
#   Extreme values on the weights will lead to very large standard errors
#   during analysis. Also, they may indicate problems in the weights model.
#
#   If you have very extreme values on the weights, look into options for
#   "truncating" the weights (e.g., Winsorization at 98th percentile). This will
#   give you lower standard errors during analysis but may leave residual
#   differences between the subsample and the full sample, even after weighting
#   (there is a tradeoff).
#
#   See here for discussion:
#
#   Heeringa, S. G., & Berglund, P. A. (2020). A guide for population-based
#     analysis of the Adolescent Brain Cognitive Development (ABCD) study
#     baseline data. BioRxiv, 2020.02.10.942011.
# ------------------------------------------------------------------------------

# Get the distribution of weights

Hmisc::describe(df.weights$ipweight)

# What are the 10 largest weights

sort(df.weights$ipweight, decreasing = TRUE) %>%
  .[1:10] %>%
  round(2)

# What are the 10 smallest weights

sort(df.weights$ipweight, decreasing = FALSE) %>%
  .[1:10] %>%
  round(2)

# ----> the distribution of weights looks okay.


# ------------------------------------------------------------------------------
# Append the estimated weights to the original dataframe
# ------------------------------------------------------------------------------

# (We use .raw version because that version does not include the changes
#  we made to address missing data on the variables in the weights model)

df.ipw.model.raw <- df.ipw.model.raw %>%
  left_join(df.weights %>%
              select(src_subject_id,
                     in.subset,
                     ipweight))


# ------------------------------------------------------------------------------
# Second, verify that after weighting, the subsample has similar means to the
# full sample on each variable in the weights model
# ------------------------------------------------------------------------------

# You could check one variable at a time like so:

#   -- Mean in full sample

df.ipw.model.raw %>%
  summarise(mean = mean(youth.black, na.rm = TRUE))

#   -- Mean in subsample, before weighting

df.ipw.model.raw %>%
  filter(in.subset == 1) %>%
  summarise(mean = mean(youth.black, na.rm = TRUE))

#  -- Mean in subsample, after weighting

df.ipw.model.raw %>%
  filter(in.subset == 1) %>%
  summarise(wtd.mean = Hmisc::wtd.mean(youth.black,
                                       weights = ipweight,
                                       na.rm = TRUE))

# Or, use this function which will calculate the means for a set of variables:

df.means <- get_means_in_unweighted_vs_weighted_samples(.data = df.ipw.model %>%
                                                          left_join(df.weights %>%
                                                                      select(src_subject_id,
                                                                             in.subset,
                                                                             ipweight)),
                                                        .identifier = "src_subject_id",
                                                        .subset = ids.subsample,
                                                        .variables = vars.weightmodel,
                                                        .weight = "ipweight")

# WARNING: This function would not work if you pass .variables
# that are factors. In that case you can either expand your factors into a
# series of dummies before passing to estimate_ipweights() or compute the means
# yourself without the help of the function.

# WARNING: Remember we modified values within df.ipw.model to handle missing values,
# imputing the mean for some observations. So do not interpret the values in df.means
# as the actual mean of the observed data.

# Inspect the means as table

df.means %>%
  pivot_wider(names_from = "metric",
              values_from = "mean")

# ^ Before weighting, completers of Year 3 are less likely to identify as Black (10.4% vs. 15.0% in full sample)
#   After weighting, completers of Year 3 are equally likely to identify as Black (15.0% vs. 15.1% in full sample)

#   Overall, the subsample (completers of Year 3, N = 6,227) has similar means along
#   the target variables in the weights model as the full sample (N = 11,876 at study entry).

#   ------> The IP weighting has achieved its goal.


# ------------------------------------------------------------------------------
# Status at the end of this script:
#   We have...
#   1. Loaded the data
#   2. Prepared a dataframe that is ready to fit the weights model to
#   3. Fit a weights model and extracted the weights
#   4. Verified the distribution of the weights is okay
#   5. Verified that after weighting, the subsample is similar to the full sample
#      on all the variables in the weighting model
# ------------------------------------------------------------------------------
