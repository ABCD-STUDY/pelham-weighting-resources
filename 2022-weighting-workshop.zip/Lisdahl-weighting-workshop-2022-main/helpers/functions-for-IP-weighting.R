# ------------------------------------------------------------------------------
# Estimate weights for a vector of idnums
# Arguments:
#   .data - dataframe with relevant variables
#   .identifier - character string for name of identifier variable (e.g., "src_subject_id")
#   .subset - vector of identifiers that is a subset of those in full sample
#   .variables - vector of variables to be included on RHS of the weights model
# ------------------------------------------------------------------------------

estimate_ipweights <- function(.data, .identifier, .subset, .variables){

  if ( ! is.data.frame(.data)) stop(".data is not a dataframe")

  if (! is.character(.identifier) | length(.identifier) != 1) stop(".identifier is not a character string")

  if (! .identifier %in% names(.data)) stop(".identifier not found in .data")

  if (any(is.na(.data))) stop(".data contains missing values")

  if ( ! is.vector(.subset)) stop(".subset is not a vector")

  if ( ! all(.subset %in% .data[[.identifier]])) stop("some element(s) of .subset was not present in .data$.identifier")

  if ( ! is.character(.variables)) stop(".variables is not a character vector")

  if (length(setdiff(.variables, names(.data))) > 0) stop("not all .variables are found in .data")

  # ...

  .data[["in.subset"]] <- ifelse(.data[[.identifier]] %in% .subset, 1, 0)

  m1 <- glm(data = .data,
            family = binomial,
            formula(paste0("in.subset ~", paste0(.variables, collapse = " + "))))

  .data[["pscore"]] <- predict(m1,
                               type = "response")

  .data[["ipweight"]] <- ifelse(.data[["in.subset"]] == 1, 1 / .data[["pscore"]], NA)

  .data

}


# ------------------------------------------------------------------------------
# Calculate means in the full sample, unweighted subsample, and weighted subsample
# Arguments:
#   .data - dataframe with relevant variables
#   .identifier - character string for name of identifier variable (e.g., "src_subject_id")
#   .subset - vector of identifiers that is a subset of those in full sample
#   .variables - vector of variables to calculate the means of
#   .weight - character string for name of IP weight variables (e.g., "ipweight")
# ------------------------------------------------------------------------------

get_means_in_unweighted_vs_weighted_samples <- function(.data, .identifier, .subset, .variables, .weight){

  if ( ! is.data.frame(.data)) stop(".data is not a dataframe")

  if (! is.character(.identifier) | length(.identifier) != 1) stop(".identifier is not a character string")

  if (! .identifier %in% names(.data)) stop(".identifier not found in .data")

  if (! is.character(.weight) | length(.weight) != 1) stop(".weight is not a character string")

  if (any(is.na(.data[, .variables]))) stop(".data contains missing values in .variables")

  if ( ! is.vector(.subset)) stop(".subset is not a vector")

  if ( ! all(.subset %in% .data[[.identifier]])) stop("some element(s) of .subset was not present in .data$.identifier")

  if ( ! is.character(.variables)) stop(".variables is not a character vector")

  if (length(setdiff(.variables, names(.data))) > 0) stop("not all .variables are found in .data")

  # ...

  .data[["weight"]] <- .data[[.weight]]

  .data.subsample <- .data[.data[[.identifier]] %in% .subset, ]

  # Calculate unweighted means for full sample
  .data %>%
    dplyr::summarise(across(.variables,
                            mean)) %>%
    dplyr::mutate(metric = "fullsample.unweighted") %>%
    # Calculate unweighted means for subsample
    dplyr::bind_rows(.data.subsample %>%
                       dplyr::summarise(across(.variables,
                                        mean)) %>%
                       dplyr::mutate(metric = "subsample.unweighted")) %>%
    # ...
    tidyr::pivot_longer(cols = .variables,
                        names_to = "variable",
                        values_to = "mean") %>%
    # Calculate weighted means for subsample
    dplyr::bind_rows(.data.subsample %>%
                       tidyr::pivot_longer(cols = .variables,
                                           names_to = "variable",
                                           values_to = "value") %>%
                       dplyr::group_by(variable) %>%
                       dplyr::summarise(mean = Hmisc::wtd.mean(value,
                                                               weights = weight,
                                                               na.rm = TRUE)) %>%
                       dplyr::mutate(metric = "subsample.weighted"))

}
