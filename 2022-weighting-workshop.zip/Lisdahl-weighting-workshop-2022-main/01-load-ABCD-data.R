# ------------------------------------------------------------------------------
# Load datafiles from NDA 4.0 release
# ------------------------------------------------------------------------------

# Where are the NDA 4.0 release files stored?

path.to.ABCD.40 <- "~/Desktop/Package_1193741/"

# Load individual files

df.lt <- read_tsv(paste0(path.to.ABCD.40, "abcd_lt01.txt"),
                  col_names = FALSE,
                  skip = 2,
                  guess_max = 1e5) %>%
  set_names(read_tsv(paste0(path.to.ABCD.40, "abcd_lt01.txt"),
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

df.acspw <- read_tsv(paste0(path.to.ABCD.40, "acspsw03.txt"),
                     col_names = FALSE,
                     skip = 2,
                     guess_max = 1e5) %>%
  set_names(read_tsv(paste0(path.to.ABCD.40, "acspsw03.txt"),
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

df.cbcl <- read_tsv(paste0(path.to.ABCD.40, "abcd_cbcls01.txt"),
                    col_names = FALSE,
                    skip = 2,
                    guess_max = 1e5) %>%
  set_names(read_tsv(paste0(path.to.ABCD.40, "abcd_cbcls01.txt"),
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

df.asr <- read_tsv(paste0(path.to.ABCD.40, "pasr01.txt"),
                    col_names = FALSE,
                    skip = 2,
                    guess_max = 1e5) %>%
  set_names(read_tsv(paste0(path.to.ABCD.40, "pasr01.txt"),
                     col_names = TRUE,
                     n_max = 0) %>%
              names())


df.subuse <- read_tsv(paste0(path.to.ABCD.40, "abcd_ysuip01.txt"),
                   col_names = FALSE,
                   skip = 2,
                   guess_max = 1e5) %>%
  set_names(read_tsv(paste0(path.to.ABCD.40, "abcd_ysuip01.txt"),
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

# ------------------------------------------------------------------------------
# Status at the end of this script:
#   We have...
#   1. Loaded the data
# ------------------------------------------------------------------------------
