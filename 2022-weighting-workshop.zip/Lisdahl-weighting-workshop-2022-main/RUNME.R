library(tidyverse)
library(sack2)
# ^ install this package, sack2, by running these commands:
#
#   install.packages("devtools")
#   devtools::install_github("wepelham3/sack2")

# Load the custom functions for weighting:
#   estimate_ipweights()
#   get_means_in_unweighted_vs_weighted_samples()

source("helpers/functions-for-IP-weighting.R")

# Example workflow #1
#   Here, I go through all the steps slowly with more comments/annotations,
#   showing the checks you should do at each intermediate step.

source("01-load-ABCD-data.R")
source("02-prepare-data-for-weights-model.R")
source("03-estimate-weights.R")
source("04-check-weighting.R")
source("05-conduct-analyses.R")

# The remaining examples, all the steps are included in a single script,
# they do not include as many checks of intermediate steps,
# and they are not as thoroughly annnotated.

# Example workflow #2
# Longitudinal regression model with *multiple rows per participant*
#    (Run scripts 01- and 02- from Example workflow #1 beforehand)

source("weighting-if-analysis-has-multiple-rows-per-participant.R")

# Example workflow #3
# Extend the U.S. Census weights from baseline to a subsample
#    (Run script 01- from Example workflow #1 beforehand)

source("extending-acs_raked_propensity_score-to-subsample.R")
