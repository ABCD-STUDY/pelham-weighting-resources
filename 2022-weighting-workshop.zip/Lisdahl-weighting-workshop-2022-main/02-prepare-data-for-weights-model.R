# ------------------------------------------------------------------------------
# Prepare a dataframe for the weights model that meets the following criteria:
#   1. One row per observation
#   2. One row for every ABCD Study participant at study entry
#   3. Contains all variables to be included in the weights model
#   4. Contains no missing values on the variables to be included in the weights model
# ------------------------------------------------------------------------------

df.ipw.model <-
  # Start with the ACS file at study entry
  df.acspw %>%
  # Merge files with additional variables to be included in the weights model
  # ... CBCL
  left_join(df.cbcl %>%
              select(src_subject_id,
                     eventname,
                     youth.cbcl.externalizing = cbcl_scr_syn_external_t,
                     youth.cbcl.internalizing = cbcl_scr_syn_internal_t)) %>%
  # ... ASR
  left_join(df.asr %>%
              select(src_subject_id,
                     eventname,
                     parent.ndays.drunk = asr_q125_p,
                     parent.ndays.drugs = asr_q126_p)) %>%
  # Retain only observations from study entry (baseline)
  filter(eventname == "baseline_year_1_arm_1") %>%
  # Recode variables as necessary
  mutate(youth.female = case_when(sex == "M" ~ 0,
                                  sex == "F" ~ 1),
         youth.black = ifelse(race_ethnicity == 2, 1, 0),
         youth.hispanic = ifelse(race_ethnicity == 3, 1, 0),
         youth.asian = ifelse(race_ethnicity == 4, 1, 0),
         youth.other = ifelse(race_ethnicity == 5, 1, 0)) %>%
  select(src_subject_id,
         eventname,
         youth.female,
         youth.black,
         youth.hispanic,
         youth.asian,
         youth.other,
         youth.cbcl.externalizing,
         youth.cbcl.internalizing,
         parent.ndays.drunk,
         parent.ndays.drugs)

# Check: is there one row per participant?

df.ipw.model %>%
  count(src_subject_id) %>%
  .[["n"]] %>%
  max()

# Check: is there one row for every participant in ABCD?

nrow(df.ipw.model)

# Check: does it contain all the variables I want to include in my weights model?

names(df.ipw.model)

# Check: how many missing values on each variable?

df.ipw.model %>%
  describe_df() %>%
  select(variable, n, nmis)

# Save a version of this dataframe that does NOT include any modifications
# you make to address missing data on variables in the weights model

df.ipw.model.raw <- df.ipw.model


# ------------------------------------------------------------------------------
# Address missing values in variables for the weights model
# ------------------------------------------------------------------------------

# For [youth.black, youth.hispanic, youth.asian, youth.other],
# create fifth dummy variable that captures a missing value for the race/ethnicity variable

df.ipw.model %>%
  select(youth.black,
         youth.hispanic,
         youth.asian,
         youth.other) %>%
  count_NA_patterns()

df.ipw.model <- df.ipw.model %>%
  mutate(youth.raceth.eqmissing = ifelse(is.na(youth.black), 1, 0),
         across(c(youth.black,
                  youth.hispanic,
                  youth.asian,
                  youth.other),
                ~ ifelse(is.na(.x), 0, .x)))

# Check missing values after that modification:

df.ipw.model %>%
  describe_df() %>%
  select(variable, n, nmis)

# For [youth.cbcl.externalizing, youth.cbcl.internalizing, parent.ndays.drunk, parent.ndays.drugs],
# use "imputation with constant plus missingness indicators" (Cham et al., 2016)

vars.for.imputation.with.constant.plus.missingness.indicators <- c("youth.cbcl.externalizing",
                                                                   "youth.cbcl.internalizing",
                                                                   "parent.ndays.drunk",
                                                                   "parent.ndays.drugs")
# -- 1. Create missingness indicators.

df.ipw.model <- df.ipw.model %>%
  mutate(across(all_of(vars.for.imputation.with.constant.plus.missingness.indicators),
                funs(Ri = ifelse(is.na(.), 1, 0))))

# -- 2. Impute missing values as a constant, the mean.

df.ipw.model <- df.ipw.model %>%
  mutate(across(all_of(vars.for.imputation.with.constant.plus.missingness.indicators),
                ~ ifelse(is.na(.x), mean(.x, na.rm = TRUE), .x)))

# Check missing values after that modification:

df.ipw.model %>%
  describe_df() %>%
  select(variable, n, nmis)

# ----> NO MISSING VALUES REMAIN (as desired)

# Check for perfect collinearity amongst the variables in the weights model:

df.ipw.model %>%
  select(-src_subject_id,
         -eventname) %>%
  cor0() %>%
  arrange(desc(abs(estimate)))

# ----> All cases who are missing a value on youth.cbcl.internalizing are also
#       missing a value on youth.cbcl.externalizing. Therefore youth.cbcl.internalizing_Ri
#       and youth.cbcl.externalizing_Ri are perfectly correlated; only one should be
#       included in the weights model.


# ------------------------------------------------------------------------------
# Status at end of this script:
#   We have...
#   1. Loaded the data
#   2. Prepared a dataframe that is ready to fit the weights model to
# ------------------------------------------------------------------------------
