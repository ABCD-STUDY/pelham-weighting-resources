# Key difference in this example:

# There are multiple rows of data per participant
#   i.e., multiple observations per participant
# We now need multiple sets of weights, one for each wave of data

# (First run scripts 01-02 from Example workflow #1)

# ------------------------------------------------------------------------------
# Estimate weights
# ------------------------------------------------------------------------------

# Define subsamples

df.usable.observations <- df.lt %>%
  # Restrict observations to the cases we can include in our analysis
  left_join(df.subuse %>%
              transmute(src_subject_id,
                        eventname,
                        ever.sipped = ifelse(su_isip_1_calc_l > 0, 1, 0))) %>%
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              transmute(src_subject_id,
                        youth.cbcl.externalizing = cbcl_scr_syn_external_t)) %>%
  drop_na(ever.sipped,
          youth.cbcl.externalizing) %>%
  select(src_subject_id,
         eventname)

ids.subsample.Y1 <- df.usable.observations %>%
  filter(eventname == "1_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

ids.subsample.Y2 <- df.usable.observations %>%
  filter(eventname == "2_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

ids.subsample.Y3 <- df.usable.observations %>%
  filter(eventname == "3_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

list(ids.subsample.Y1,
     ids.subsample.Y2,
     ids.subsample.Y3) %>%
  map(length)

# Choose variables for weights model

vars.weightmodel <- c("youth.female",
                      "youth.black",
                      "youth.hispanic",
                      "youth.asian",
                      "youth.other",
                      "youth.cbcl.externalizing",
                      "youth.cbcl.internalizing",
                      "parent.ndays.drunk",
                      "parent.ndays.drugs",
                      "youth.cbcl.externalizing_Ri",
                      # "youth.cbcl.internalizing_Ri",
                      #    ^ We exclude this variable because it is perfectly correlated
                      #      with youth.cbcl.externalizing_Ri
                      "parent.ndays.drunk_Ri",
                      "parent.ndays.drugs_Ri")

# Estimates sets of ipweights

df.weights.Y1 <- estimate_ipweights(.data = df.ipw.model,
                                    .identifier = "src_subject_id",
                                    .subset = ids.subsample.Y1,
                                    .variables = vars.weightmodel) %>%
  mutate(eventname = "1_year_follow_up_y_arm_1")

df.weights.Y2 <- estimate_ipweights(.data = df.ipw.model,
                                    .identifier = "src_subject_id",
                                    .subset = ids.subsample.Y2,
                                    .variables = vars.weightmodel) %>%
  mutate(eventname = "2_year_follow_up_y_arm_1")

df.weights.Y3 <- estimate_ipweights(.data = df.ipw.model,
                                    .identifier = "src_subject_id",
                                    .subset = ids.subsample.Y3,
                                    .variables = vars.weightmodel) %>%
  mutate(eventname = "3_year_follow_up_y_arm_1")

# Check distribution of weights

Hmisc::describe(df.weights.Y1$ipweight)

Hmisc::describe(df.weights.Y2$ipweight)

Hmisc::describe(df.weights.Y3$ipweight)

# Check means in weighted subsamples vs. full sample

get_means_in_unweighted_vs_weighted_samples(.data = df.ipw.model %>%
                                              left_join(df.weights.Y1 %>%
                                                          select(src_subject_id,
                                                                 in.subset,
                                                                 ipweight)),
                                            .identifier = "src_subject_id",
                                            .subset = ids.subsample.Y1,
                                            .variables = vars.weightmodel,
                                            .weight = "ipweight") %>%
  pivot_wider(names_from = "metric",
              values_from = "mean")

get_means_in_unweighted_vs_weighted_samples(.data = df.ipw.model %>%
                                              left_join(df.weights.Y2 %>%
                                                          select(src_subject_id,
                                                                 in.subset,
                                                                 ipweight)),
                                            .identifier = "src_subject_id",
                                            .subset = ids.subsample.Y2,
                                            .variables = vars.weightmodel,
                                            .weight = "ipweight") %>%
  pivot_wider(names_from = "metric",
              values_from = "mean")

get_means_in_unweighted_vs_weighted_samples(.data = df.ipw.model %>%
                                              left_join(df.weights.Y3 %>%
                                                          select(src_subject_id,
                                                                 in.subset,
                                                                 ipweight)),
                                            .identifier = "src_subject_id",
                                            .subset = ids.subsample.Y3,
                                            .variables = vars.weightmodel,
                                            .weight = "ipweight") %>%
  pivot_wider(names_from = "metric",
              values_from = "mean")


# ------------------------------------------------------------------------------
# Conduct analyses
# ------------------------------------------------------------------------------

# Add weights to dataframe

df.analysis <-
  # Assemble time-varying part of dataframe
  df.subuse %>%
  transmute(src_subject_id,
            eventname,
            time.varying_ever.sipped = ifelse(su_isip_1_calc_l > 0, 1, 0)) %>%
  left_join(df.lt %>%
              select(src_subject_id,
                     eventname,
                     age.mos = interview_age)) %>%
  left_join(df.weights.Y1 %>%
              bind_rows(df.weights.Y2) %>%
              bind_rows(df.weights.Y3) %>%
              select(src_subject_id,
                     eventname,
                     ipweight)) %>%
  # Assemble time-invariant part of dataframe
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              transmute(src_subject_id,
                        Y0_youth.cbcl.externalizing = cbcl_scr_syn_external_t)) %>%
  # Filter to complete cases that can be used in analysis
  drop_na(src_subject_id,
          time.varying_ever.sipped,
          Y0_youth.cbcl.externalizing) %>%
  # geepack wants the rows ordered and indexed with numbers
  arrange(src_subject_id,
          eventname) %>%
  group_by(src_subject_id) %>%
  mutate(subj.index = cur_group_id()) %>%
  ungroup()

# Observe that the same participant now has different weights at different waves:

df.analysis %>%
  select(src_subject_id,
         eventname,
         ipweight) %>%
  pivot_wider(names_from = "eventname",
              values_from = "ipweight")

# Fit a longitudinal model in geepack that includes multiple rows per participant

# library(geepack)
#
# fit.weighted <- geeglm(time.varying_ever.sipped ~ Y0_youth.cbcl.externalizing + age.mos,
#                        id = df.analysis$subj.index,
#                        weights = df.analysis$ipweight,
#                        corstr = "exchangeable",
#                        std.err = "san.se",
#                        data = df.analysis)
#
# nobs(fit.weighted)
#
# broom::tidy(fit.weighted)
#
# # For comparison, unweighted estimates
#
# fit.unweighted <- geeglm(time.varying_ever.sipped ~ Y0_youth.cbcl.externalizing + age.mos,
#                          id = df.analysis$subj.index,
#                          corstr = "exchangeable",
#                          std.err = "san.se",
#                          data = df.analysis)
#
# nobs(fit.unweighted)
#
# broom::tidy(fit.unweighted)

# geepack is very slow with large datasets!
# Here we use geeM instead of geepack:
#    https://journal.r-project.org/archive/2013/RJ-2013-017/RJ-2013-017.pdf

library(geeM)

fit.weighted <- geem(time.varying_ever.sipped ~ Y0_youth.cbcl.externalizing + age.mos,
                     id = df.analysis$subj.index,
                     weights = df.analysis$ipweight,
                     corstr = "exchangeable",
                     data = df.analysis)

summary(fit.weighted)

# For comparison, unweighted estimates

fit.unweighted <- geem(time.varying_ever.sipped ~ Y0_youth.cbcl.externalizing + age.mos,
                       id = df.analysis$subj.index,
                       corstr = "exchangeable",
                       data = df.analysis)

summary(fit.unweighted)
