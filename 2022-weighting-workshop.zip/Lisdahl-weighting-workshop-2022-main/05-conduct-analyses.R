# ------------------------------------------------------------------------------
# Add weights to a dataframe for analysis
# ------------------------------------------------------------------------------

df.analysis <- df.acspw %>%
  filter(eventname == "baseline_year_1_arm_1") %>%
  select(src_subject_id) %>%
  # Add variables for analysis
  left_join(df.subuse %>%
              filter(eventname == "3_year_follow_up_y_arm_1") %>%
              transmute(src_subject_id,
                        Y3_ever.sipped = ifelse(su_isip_1_calc_l > 0, 1, 0))) %>%
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              transmute(src_subject_id,
                        Y0_youth.cbcl.externalizing = cbcl_scr_syn_external_t)) %>%
  # Filter to complete cases that can be used in analysis
  drop_na(src_subject_id,
          Y3_ever.sipped,
          Y0_youth.cbcl.externalizing)

# Check: do we have an estimated weight for every observation?

setdiff(df.analysis$src_subject_id,
        filter(df.weights, ! is.na(ipweight))[["src_subject_id"]])

# Check: did we accidentally estimate a weight for any observation NOT in the analysis?
# (that would mean the weights are wrong and should be re-estimated with a different subsample)

setdiff(filter(df.weights, ! is.na(ipweight))[["src_subject_id"]],
        df.analysis$src_subject_id)

# If those checks are passed, merge the weights

df.analysis <- df.analysis %>%
  left_join(df.weights %>%
              select(src_subject_id,
                     ipweight))

# ------------------------------------------------------------------------------
# Descriptive statistics
# ------------------------------------------------------------------------------

library(survey)

# What is the prevalence of alcohol sipping?

df.analysis %>%
  summarise(prevalence = Hmisc::wtd.mean(Y3_ever.sipped,
                                         weights = ipweight))

# With a confidence interval

svyciprop(~ Y3_ever.sipped,
          design = svydesign(ids = ~ 1,
                             weights = ~ ipweight,
                             data = df.analysis),
          method = "logit")

# For comparison, what is the unweighted estimate?

df.analysis %>%
  summarise(prevalence = mean(Y3_ever.sipped))


# ------------------------------------------------------------------------------
# Regression model (with one row per participant) using survey
# ------------------------------------------------------------------------------

fit.weighted <- svyglm(Y3_ever.sipped ~ Y0_youth.cbcl.externalizing,
                       design = svydesign(ids = ~ 1, # replace this with "~ family" to account for clustering within families
                                          weights = ~ ipweight,
                                          data = df.analysis))

nobs(fit.weighted)

broom::tidy(fit.weighted)

# For comparison, what is the unweighted estimate?

fit.unweighted <- glm(Y3_ever.sipped ~ Y0_youth.cbcl.externalizing,
                      data = df.analysis)

nobs(fit.unweighted)

broom::tidy(fit.unweighted)
