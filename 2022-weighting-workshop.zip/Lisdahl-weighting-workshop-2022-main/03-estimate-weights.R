# ------------------------------------------------------------------------------
# Define the subsample you want to weight
# ------------------------------------------------------------------------------

# In this example, we want to estimate the prevalence of alcohol sipping measured
# at Year 3 and examine its correlation with youth externalizing problems measured
# at baseline.

# Create vector with all idnums in the subsample we wish to weight

ids.subsample <- df.lt %>%
  filter(eventname == "3_year_follow_up_y_arm_1") %>%
  # Further restrict observations to the cases we can include in our analysis
  # relating alcohol sipping at Year 3 to externalizing problems at baseline
  left_join(df.subuse %>%
              filter(eventname == "3_year_follow_up_y_arm_1") %>%
              transmute(src_subject_id,
                        eventname,
                        ever.sipped = ifelse(su_isip_1_calc_l > 0, 1, 0))) %>%
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              transmute(src_subject_id,
                        youth.cbcl.externalizing = cbcl_scr_syn_external_t)) %>%
  drop_na(ever.sipped,
          youth.cbcl.externalizing) %>%
  # Extract a list of which observations which remain
  .[["src_subject_id"]]

# How many observations are in this subsample?

length(ids.subsample)


# ------------------------------------------------------------------------------
# Choose which variables to include in the weights model
# ------------------------------------------------------------------------------

# Create vector with names of the variables in weight model
#   WARNING: you must include the new _Ri variables if you used "imputation with
#   constant plus missingness indicators" (Cham et al., 2016)

# NOTE: All variables in the weights model should be measured at Baseline (study entry)
#       Variables from subsequent waves could possibly be used but only in a more
#       complicated setup.

vars.weightmodel <- c("youth.female",
                      "youth.black",
                      "youth.hispanic",
                      "youth.asian",
                      "youth.other",
                      "youth.cbcl.externalizing",
                      "youth.cbcl.internalizing",
                      "parent.ndays.drunk",
                      "parent.ndays.drugs",
                      "youth.cbcl.externalizing_Ri",
                      # "youth.cbcl.internalizing_Ri",
                      #    ^ We exclude this variable because it is perfectly correlated
                      #      with youth.cbcl.externalizing_Ri
                      "parent.ndays.drunk_Ri",
                      "parent.ndays.drugs_Ri")

# ------------------------------------------------------------------------------
# Estimate IP weights for those who participated in 3-year follow-up
# ------------------------------------------------------------------------------

# Estimate weights for that subsample

df.weights <- estimate_ipweights(.data = df.ipw.model,
                                 .identifier = "src_subject_id",
                                 .subset = ids.subsample,
                                 .variables = vars.weightmodel)

# df.weights is now df.ipw.model + 3 new columns:

# "in.subset" - dummy variable indicating whether the observation is in the
#               subsample to be weighted
#
# "pscore" - the estimated probability of being in the subsample, given the
#            observation's values on the variables in the weighting model
#
# 'ipweight" - the inverse probability weight (for observations in the subsample, 1 / pscore)

# Double-check that the number of observations in the subset is correct:

vals(df.weights$in.subset)

# ------------------------------------------------------------------------------
# Status at the end of this script:
#   We have...
#   1. Loaded the data
#   2. Prepared a dataframe that is ready to fit the weights model to
#   3. Fit a weights model and extracted the weights
# ------------------------------------------------------------------------------
