# Key difference in this example:

# All the variables that were included in the creation of acs_raked_propensity_score
# must also be included in our weights for the subsample.

# We create weights for the subsample, then multiple those weights by acs_raked_propensity_score.

#   (First run 01-load-ABCD-data.R from Example workflow #1)
# ------------------------------------------------------------------------------
# First, create the same dataframe that was used to create acs_raked_propensity_score
#   This is complicated because it involves a bunch of recoding, imputation
#   The script below will handle this for you...
# ------------------------------------------------------------------------------

# Where are all the NDA 3.0 release files located?
# 3.0 is necessary because that is the release used to create acs_raked_propensity_score

path.to.ABCD.30 <- "~/Desktop/abcd-data-local/ABCDStudyNDA/"

source("helpers/create-dataframe-from-acs_raked_propensity_score.R")

# Get variables from acs_raked_propensity_score weights model for only ABCD Study participants

df.ipw.model <- nov2018_acs_abcd_i %>%
  filter(acsflag == 0) %>%
  select(src_subject_id,
         age,
         faminc,
         famtype,
         c_fesabcd,
         hhsize,
         c_race_eth,
         region,
         sex) %>%
  mutate(across(c(-src_subject_id),
                factor))

# We now have a dataframe with (hopefully) the exact values of covariates
# included in the propensity model for acs_raked_propensity_score.

# Now, add in any other variables you wish to include in the weights model

df.ipw.model <- df.ipw.model %>%
  # Merge files with additional variables to be included in the weights model
  # ... CBCL
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              select(src_subject_id,
                     youth.cbcl.externalizing = cbcl_scr_syn_external_t,
                     youth.cbcl.internalizing = cbcl_scr_syn_internal_t)) %>%
  # ... ASR
  left_join(df.asr %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              select(src_subject_id,
                     parent.ndays.drunk = asr_q125_p,
                     parent.ndays.drugs = asr_q126_p))

# Address some missing values in the variables we added

vars.for.imputation.with.constant.plus.missingness.indicators <- c("youth.cbcl.externalizing",
                                                                   "youth.cbcl.internalizing",
                                                                   "parent.ndays.drunk",
                                                                   "parent.ndays.drugs")
# -- 1. Create missingness indicators.

df.ipw.model <- df.ipw.model %>%
  mutate(across(all_of(vars.for.imputation.with.constant.plus.missingness.indicators),
                funs(Ri = ifelse(is.na(.), 1, 0))))

# -- 2. Impute missing values as a constant, the mean.

df.ipw.model <- df.ipw.model %>%
  mutate(across(all_of(vars.for.imputation.with.constant.plus.missingness.indicators),
                ~ ifelse(is.na(.x), mean(.x, na.rm = TRUE), .x)))

# Check missing values after that modification:

df.ipw.model %>%
  describe_df() %>%
  select(variable, n, nmis)


# ------------------------------------------------------------------------------
# Now, use that dataframe to estimate IP weights that extend the
# acs_raked_propensity_score weights to a subsample of ABCD participants
# ------------------------------------------------------------------------------

# Define target subsample -- e.g., completers of Year 3

ids.subsample <- read_tsv(paste0(path.to.ABCD.40, "abcd_lt01.txt"),
                          col_names = FALSE,
                          skip = 2,
                          guess_max = 1e5) %>%
  set_names(read_tsv(paste0(path.to.ABCD.40, "abcd_lt01.txt"),
                     col_names = TRUE,
                     n_max = 0) %>%
              names()) %>%
  filter(eventname == "3_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

length(ids.subsample)

# Create vector with names of the variables in weight model

vars.weightmodel <-
  c(
  # First, the variables that were used in creating acs_raked_propensity_score
  "age",
  "faminc",
  "famtype",
  "c_fesabcd",
  "hhsize",
  "c_race_eth",
  "region",
  "sex",
  # Second, any additional variables of interest for your own analysis
  #   (don't re-list any that were already included above)
  "youth.cbcl.externalizing",
  "youth.cbcl.internalizing",
  "parent.ndays.drunk",
  "parent.ndays.drugs",
  "youth.cbcl.externalizing_Ri",
  "parent.ndays.drunk_Ri",
  "parent.ndays.drugs_Ri"
)

# Estimate weights for that subsample

df.weights <- estimate_ipweights(.data = df.ipw.model,
                                 .identifier = "src_subject_id",
                                 .subset = ids.subsample,
                                 .variables = vars.weightmodel)

# Check distribution of weights

Hmisc::describe(df.weights$ipweight)

# Append weights

df.ipw.model <- df.ipw.model %>%
  left_join(df.weights %>%
              select(src_subject_id,
                     in.subset,
                     ipweight)) %>%
  left_join(read_tsv(paste0(path.to.ABCD.30, "acspsw03.txt"),
                     col_names = FALSE,
                     skip = 2,
                     guess_max = 1e5) %>%
              set_names(read_tsv(paste0(path.to.ABCD.30, "acspsw03.txt"),
                                 col_names = TRUE,
                                 n_max = 0) %>%
                          names()) %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              select(src_subject_id,
                     acs_raked_propensity_score)) %>%
  # Multiple the acs_raked_propensity_score weight by the ipweight we
  # created to make the subsample representative of the full sample
  mutate(product.weight = ipweight * acs_raked_propensity_score)

# Inspect product weight

Hmisc::describe(df.ipw.model$product.weight)


# ------------------------------------------------------------------------------
# Check that the product.weight-weighted subsample looks like the acs_raked_propensity_score-weighted full sample
# ------------------------------------------------------------------------------

# The variables used in creating acs_raked_propensity_score were multilevel factors,
# so in order to look at means we need to first convert into a series of dummy variables.

df.ipw.model.dummied <- df.ipw.model %>%
  fastDummies::dummy_cols(select_columns = c("age",
                                             "faminc",
                                             "famtype",
                                             "c_fesabcd",
                                             "hhsize",
                                             "c_race_eth",
                                             "region",
                                             "sex"))

# We also need a list of the names of the new dummy variables

vars.weightmodel.dummied <- setdiff(names(df.ipw.model.dummied),
                                    names(df.ipw.model))

# Append this to the list of variables you added to the weights model for your own analysis

vars.weightmodel.dummied <- setdiff(vars.weightmodel,
                                    c("age",
                                      "faminc",
                                      "famtype",
                                      "c_fesabcd",
                                      "hhsize",
                                      "c_race_eth",
                                      "region",
                                      "sex")) %>%
  c(vars.weightmodel.dummied)

# Calculate means for comparison along the variables used in creating acs_raked_propensity_score

# Now calculate means for comparison

df.ipw.model.dummied %>%
  mutate(group = "fullsample") %>%
  # append rows for subsample
  bind_rows(df.ipw.model.dummied %>%
              filter(in.subset == 1) %>%
              mutate(group = "subsample")) %>%
  # ...
  pivot_longer(cols = all_of(vars.weightmodel.dummied),
               names_to = "variable",
               values_to = "value") %>%
  group_by(group, variable) %>%
  summarise(unweighted = mean(value,
                              na.rm = TRUE),
            weighted = Hmisc::wtd.mean(value,
                                       weights = product.weight,
                                       na.rm = TRUE)) %>%
  # wrangle
  pivot_longer(cols = c(unweighted,
                        weighted),
               names_to = "metric",
               values_to = "value") %>%
  unite("colname", group, metric, sep = "_") %>%
  pivot_wider(names_from = "colname",
              values_from = "value") %>%
  mutate_if(is.numeric,
            ~ round(.x, 2)) %>%
  as.data.frame()


# ------------------------------------------------------------------------------
# Conduct analyses
# ------------------------------------------------------------------------------

# Prepare data

df.analysis <- df.acspw %>%
  filter(eventname == "baseline_year_1_arm_1") %>%
  select(src_subject_id) %>%
  # Add variables for analysis
  left_join(df.subuse %>%
              filter(eventname == "3_year_follow_up_y_arm_1") %>%
              transmute(src_subject_id,
                        Y3_ever.sipped = ifelse(su_isip_1_calc_l > 0, 1, 0))) %>%
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              transmute(src_subject_id,
                        Y0_youth.cbcl.externalizing = cbcl_scr_syn_external_t)) %>%
  # Filter to complete cases that can be used in analysis
  drop_na(src_subject_id,
          Y3_ever.sipped,
          Y0_youth.cbcl.externalizing) %>%
  # Append weights
  left_join(df.ipw.model %>%
              select(src_subject_id,
                     ipweight,
                     product.weight))

# Fit model weighted with ipweight...
#   This only addresses missing data
#   Now those in analysis are reflective of full sample along the variables in vars.weightmodel

library(survey)

fit.weighted1 <- svyglm(Y3_ever.sipped ~ Y0_youth.cbcl.externalizing,
                        design = svydesign(ids = ~ 1,
                                           weights = ~ ipweight,
                                           data = df.analysis))

nobs(fit.weighted1)

summary(fit.weighted1)

# Fit model weighted with product.weight...
#   This addressed both missing data and sample non-representativeness
#   Now those in analysis are reflective of full sample at study entry along the variables in vars.weightmodel
#   that you added for your own analysis (), and of the children in the ACS Census along the variables
#   in vars.weightmodel that were used when creating acs_raked_propensity_score

fit.weighted2 <- svyglm(Y3_ever.sipped ~ Y0_youth.cbcl.externalizing,
                        design = svydesign(ids = ~ 1,
                                           weights = ~ product.weight,
                                           data = df.analysis))

nobs(fit.weighted2)

summary(fit.weighted2)

