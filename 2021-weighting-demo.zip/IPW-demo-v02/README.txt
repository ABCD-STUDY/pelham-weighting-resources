The files in this directory show how to estimate inverse probability weights for a subsample of ABCD participants using data from the 3.0 release.

First, some working directory issues:

Near the top of example-application-01.R, set the working directory to the location of the data files in the 3.0 release.

In example-application-02.R, I use another file (ACS2011_15_I.Rds) that is included in this directory but not the 3.0 release. So you should either move this file (ACS2011_15_I.Rds) to the same location as your 3.0 data files or alter the path within the file creating-dataframe-from-acs_raked_propensity_score.R.

I recommend looking at the files in the order below:

1. functions-for-IP-weighting.R

This script defines two functions that are used in the other scripts.

2. example-application-01.R

This script shows how to use the weighting functions to create IP weights for a specific application.

3. example-application-02.R

This script shows how to use the weighting functions to create IP weights that extend the acs_raked_propensity_score weight. This is a more complicated process because you must first recreate the dataframe used in estimating the acs_raked_propensity_score weight -- there is lots of recoding and imputation necessary to manipulate 3.0 release data into the appropriate form.

4. ACS2011_15_I.Rds

This is a datafile necessary for extending the acs_raked_propensity_score to subsamples of ABCD participants.
