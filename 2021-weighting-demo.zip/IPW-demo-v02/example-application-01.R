# This script shows how to take the general functions, estimate_ipweights() and
# get_means_in_unweighted_vs_weighted_sample(), and apply them in a specific
# instance.

# The functions are intended to be general in the following sense. There are
# many possible situations in which you would want to use weighting to create a
# pseudopopulation that it is representative of the full ABCD sample at study
# entry, along some characteristics X, Y, Z, etc. What these situations all
# share is that (1) there is a target subsample, or subset of members of the
# full ABCD sample, and (2) there is a target set of characteristics along which
# you would like to make that subsample representative of the full ABCD sample.
# Given these two inputs and a dataframe with the relevant variables, the
# estimate_ipweights() function will estimate IP weights. This should permit it to
# work in many different situations (e.g., addressing longitudinal attrition, or
# addressing pandemic-induced missingness on a specific measure).

# For illustration, I created IP weights for completers of the 2-year
# follow-up. The variables I included the weights model (i.e., sought to achieve
# representativeness upon) were a mix of binary variables (e.g., youth sex) and
# continuous variables (e.g., youth CBCL t-score for externalizing problems).

# Roughly, the process in this script goes like so:

# 1. Define your target subsample--create a vector of their ID numbers.

# 2. Choose the variables you want in the weighting model--create a vector of their names.

# 3. Create a dataframe with the full sample (N = 11878), the variables you want
#    in the weighting model, and no missing data.

# 4. Use estimate_ipweights() to estimate the IP weights.

# 5. Check the distribution of the weights for any extreme values

# 6. Compare the means of each variable within the full sample, unweighted
#    subsample, and weighted subsample. If the IP weighting process was successful,
#    then you should obtain similar means in the full sample and the weighted
#    subsample.

library(tidyverse)

source("functions-for-IP-weighting.R")

# Location of data from 3.0 release

setwd("~ABCDStudyNDA")

# ------------------------------------------------------------------------------
# Load data from 3.0 release
# ------------------------------------------------------------------------------

df.lt <- read_tsv("abcd_lt01.txt",
                  col_names = FALSE,
                  skip = 2,
                  guess_max = 1e5) %>%
  set_names(read_tsv("abcd_lt01.txt",
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

df.acspw <- read_tsv("acspsw03.txt",
                     col_names = FALSE,
                     skip = 2,
                     guess_max = 1e5) %>%
  set_names(read_tsv("acspsw03.txt",
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

df.cbcl <- read_tsv("abcd_cbcls01.txt",
                    col_names = FALSE,
                    skip = 2,
                    guess_max = 1e5) %>%
  set_names(read_tsv("abcd_cbcls01.txt",
                     col_names = TRUE,
                     n_max = 0) %>%
              names())

# ------------------------------------------------------------------------------
# Prepare a dataframe with no missing values for the weights model
# ------------------------------------------------------------------------------

df.ipw.model <- df.acspw %>%
  left_join(df.cbcl %>%
              select(src_subject_id,
                     eventname,
                     youth.cbcl.externalizing = cbcl_scr_syn_external_t,
                     youth.cbcl.internalizing = cbcl_scr_syn_internal_t)) %>%
  filter(eventname == "baseline_year_1_arm_1") %>%
  mutate(youth.female = case_when(sex == "M" ~ 0,
                                  sex == "F" ~ 1),
         youth.black = ifelse(race_ethnicity == 2, 1, 0),
         youth.hispanic = ifelse(race_ethnicity == 3, 1, 0),
         youth.asian = ifelse(race_ethnicity == 4, 1, 0),
         youth.other = ifelse(race_ethnicity == 5, 1, 0)) %>%
  select(src_subject_id,
         eventname,
         youth.female,
         youth.black,
         youth.hispanic,
         youth.asian,
         youth.other,
         youth.cbcl.externalizing,
         youth.cbcl.internalizing) %>%
  # median imputation for these variables, all of which have N <= 6 missing values
  mutate(across(everything(),
                ~ ifelse(is.na(.x), median(.x, na.rm = TRUE), .x)))

# This dataframe should not have any missing values. Options to get around that:
# - some form of single imputation
# - convert variable into a set of dummies, where one category reflects missing values


# ------------------------------------------------------------------------------
# Estimate IP weights for those who participated in 2-year follow-up
# ------------------------------------------------------------------------------

# Create vector with all idnums in the subsample

ids.subsample <- df.lt %>%
  filter(eventname == "2_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

# Create vector with names of the variables in weight model

vars.weightmodel <- c("youth.female",
                      "youth.black",
                      "youth.hispanic",
                      "youth.asian",
                      "youth.other",
                      "youth.cbcl.externalizing",
                      "youth.cbcl.internalizing")

# ^ NOTE. to include product terms or higher-order terms, define them a priori
# and then include the names of those new variables in this vector. That will
# ensure both the weighting functions work appropriately. For multilevel
# factors, if you declare them as factors beforehand, then estimate_ipweights()
# will treat them as factors, but get_means_in_unweighted_vs_weighted_samples()
# will not be usable. See end of example-application-02.R for an example of how
# to handle multilevel factors using fastDummies package.

# Estimate weights for that subsample

df.weights <- estimate_ipweights(.data = df.ipw.model,
                                 .identifier = "src_subject_id",
                                 .subset = ids.subsample,
                                 .variables = vars.weightmodel)

# Inspect the estimated weights

Hmisc::describe(df.weights$ipweight)

sort(df.weights$ipweight, decreasing = TRUE)[1:10]

# ^ NOTE. if you observe very large weights, you may want to truncate them
# before continuing. See Heeringa et al. 2020 arxiv for discussion.

# Append the estimated weights to original data

df.ipw.model2 <- df.ipw.model %>%
  left_join(df.weights)

# Calculate means of covariates in full sample vs. unweighted subsample vs.
# weighted subsample. NOTE. this function would not work if you pass .variables
# that are factors. In that case you can either expand your factors into a
# series of dummies before passing to estimate_ipweights() or compute the means
# yourself without the help of the function.

df.means <- get_means_in_unweighted_vs_weighted_samples(.data = df.ipw.model2,
                                                        .identifier = "src_subject_id",
                                                        .subset = ids.subsample,
                                                        .variables = vars.weightmodel,
                                                        .weight = "ipweight")

# Inspect the means as table

df.means %>%
  pivot_wider(names_from = "metric",
              values_from = "mean")

# ^ Before weighting, completers of year 2 are less likely to be Black (11.7% vs. 15.0% in full sample)
#   After weighting, completers of year 2 are equally likely to be Black (15.0% vs. 15.0% in full sample)

#   Overall, the subsample (completers of 2-year follow-up, N = 6571) has similar means along
#   the target variables as the full sample (N = 11878 at study entry). The IP weighting has achieved
#   its goal.


# ------------------------------------------------------------------------------
# What if you need to create multiple sets of weights?
#
# e.g., different analyses within same paper use different subset of cases,
#       or you want to estimate weights for multiple longitudinal waves

# You can just repeat the process above multiple times, each time passing
# different .subsamples. If you want to vectorize that process to avoid
# repeating code, below is one example of how to do that.
#
# I create weights for the 18-month, 24-month, and 30-month follow-ups,
# plus a random subset made to show systematic attrition.
# ------------------------------------------------------------------------------

ids.subsample1 <- df.lt %>%
  filter(eventname == "18_month_follow_up_arm_1") %>%
  .[["src_subject_id"]]

ids.subsample2 <- df.lt %>%
  filter(eventname == "2_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

ids.subsample3 <- df.lt %>%
  filter(eventname == "30_month_follow_up_arm_1") %>%
  .[["src_subject_id"]]

# simulate future wave with systematic attrition as a function of externalizing

ids.subsample4 <- df.lt %>%
  filter(eventname == "30_month_follow_up_arm_1") %>%
  left_join(df.cbcl %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              select(src_subject_id,
                     cbcl_scr_syn_external_t)) %>%
  mutate(risk = ifelse(cbcl_scr_syn_external_t >= 60, .10, .60)) %>%
  bind_cols(participated = rbinom(n = nrow(.),
                                  size = 1,
                                  prob = .$risk)) %>%
  filter(participated == 1) %>%
  .[["src_subject_id"]]

# estimate the weights for each subsample

df.weights2 <-
  mapply(FUN = function(x, name){

                  data <- estimate_ipweights(.data = df.ipw.model,
                                             .identifier = "src_subject_id",
                                             .subset = x,
                                             .variables = vars.weightmodel)

                  names(data)[names(data) == 'ipweight'] <- paste0('ipweight_', name)

                  data

                },
          # list of vectors of identifiers for each subsample
          x = list(ids.subsample1,
                   ids.subsample2,
                   ids.subsample3,
                   ids.subsample4),
          # unique names for the weights for each subsample
          name = c("18mo",
                   "24mo",
                   "30mo",
                   "hypo"),
          SIMPLIFY = FALSE) %>%
  lapply(FUN = function(data){select(data, src_subject_id, matches("ipweight"))}) %>%
  reduce(full_join)

# merge the weights

df.ipw.model3 <- df.ipw.model %>%
  left_join(df.weights2)

# check the unweighted/weighted means in each subsample, relative to full sample

mapply(FUN = function(x, name){

         data <- get_means_in_unweighted_vs_weighted_samples(.data = df.ipw.model3,
                                                             .identifier = "src_subject_id",
                                                             .subset = x,
                                                             .variables = vars.weightmodel,
                                                             .weight = paste0("ipweight_", name))

         data$subsample <- name

         data

       },
       # list of vectors of identifiers for each subsample
       x = list(ids.subsample1,
                ids.subsample2,
                ids.subsample3,
                ids.subsample4),
       # unique names for the weights for each subsample
       name = c("18mo",
                "24mo",
                "30mo",
                "hypo"),
       SIMPLIFY = FALSE) %>%
  map(~ .x %>%
        pivot_wider(names_from = "metric",
                    values_from = "mean"))
