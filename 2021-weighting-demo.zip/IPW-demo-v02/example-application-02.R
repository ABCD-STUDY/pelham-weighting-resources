# This application shows how to estimate IP weights while including the exact
# same covariates in the weights model as were included in calculating the
# acs_raked_propensity_score weight. This is desirable because you can then
# multiply the estimated IP weight for your subsample by the
# acs_raked_propensity score to create a new weight. When weighted by this
# product weight, the subsample will be a pseudopopulation that is reflects the
# distribution of the ACS sample along the variables included in estimating the
# acs_raked_propensity_score weight (see Heeringa et al. 2020 arxiv).

# To hew as closely as possible to the procedure used in estimating the
# acs_raked_propensity_score weight, we create the dataframe for
# estimate_ipweights() using minimally adapted code found at the following
# address to use data included in the 3.0 release.

# https://github.com/ABCD-STUDY/abcd_acs_raked_propensity

library(tidyverse)
library(mice)
library(survey)

source("functions-for-IP-weighting.R")

# Location of data from 3.0 release

setwd("~/Desktop/ABCDStudyNDA")

# Create dataframe used in estimating acs_raked_propensity_score

source("create-dataframe-from-acs_raked_propensity_score.R")

# Restrict to just ABCD participants

df.acs.ipw.model <- nov2018_acs_abcd_i %>%
  filter(acsflag == 0) %>%
  select(src_subject_id,
         age,
         faminc,
         famtype,
         c_fesabcd,
         hhsize,
         c_race_eth,
         region,
         sex) %>%
  mutate(across(c(-src_subject_id),
                factor))

# We now have a dataframe with (hopefully) the exact values of covariates
# included in the propensity model for acs_raked_propensity_score.


# ------------------------------------------------------------------------------
# Now, use that dataframe to estimate IP weights that extend the
# acs_raked_propensity_score weights to a subsample of ABCD participants
# ------------------------------------------------------------------------------

# Create vector with all idnums in the subsample - customize this for your analysis

ids.subsample <- read_tsv("abcd_lt01.txt",
                          col_names = FALSE,
                          skip = 2,
                          guess_max = 1e5) %>%
  set_names(read_tsv("abcd_lt01.txt",
                     col_names = TRUE,
                     n_max = 0) %>%
              names()) %>%
  filter(eventname == "2_year_follow_up_y_arm_1") %>%
  .[["src_subject_id"]]

# Create vector with names of the variables in weight model

vars.acs.weightmodel <- c("age",
                          "faminc",
                          "famtype",
                          "c_fesabcd",
                          "hhsize",
                          "c_race_eth",
                          "region",
                          "sex")

# Estimate weights for that subsample (see functions-for-IP-weighting.R)

df.weights <- estimate_ipweights(.data = df.acs.ipw.model,
                                 .identifier = "src_subject_id",
                                 .subset = ids.subsample,
                                 .variables = vars.acs.weightmodel)

# Inspect the estimated weights

Hmisc::describe(df.weights$ipweight)

sort(df.weights$ipweight, decreasing = TRUE)[1:10]

# Append weights

df.acs.ipw.model2 <- df.acs.ipw.model %>%
  left_join(df.weights) %>%
  left_join(read_tsv("acspsw03.txt",
                     col_names = FALSE,
                     skip = 2,
                     guess_max = 1e5) %>%
              set_names(read_tsv("acspsw03.txt",
                                 col_names = TRUE,
                                 n_max = 0) %>%
                          names()) %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              select(src_subject_id,
                     acs_raked_propensity_score)) %>%
  mutate(product.weight = ipweight * acs_raked_propensity_score)

# Inspect product weight

Hmisc::describe(df.acs.ipw.model2$product.weight)

sort(df.acs.ipw.model2$ipweight, decreasing = TRUE)[1:10]

# Trim and rescale product weight

df.acs.ipw.model2 <- df.acs.ipw.model2 %>%
  mutate(product.weight.trimmed = case_when(product.weight < quantile(product.weight,
                                                                      probs = .02,
                                                                      na.rm = TRUE) ~ quantile(product.weight, probs = .02, na.rm = TRUE),
                                            product.weight > quantile(product.weight,
                                                                      probs = .98,
                                                                      na.rm = TRUE) ~ quantile(product.weight, probs = .98, na.rm = TRUE),
                                            TRUE ~ product.weight),
         product.weight.trimmed.rescaled = product.weight.trimmed * (sum(dat.2011_15$PWGTP) / sum(product.weight.trimmed, na.rm = TRUE)))

# check trimming

quantile(df.acs.ipw.model2$product.weight, probs = c(.02, .98), na.rm = TRUE)
min(df.acs.ipw.model2$product.weight.trimmed, na.rm = TRUE)
max(df.acs.ipw.model2$product.weight.trimmed, na.rm = TRUE)

# check rescaling - these numbers should be the same

sum(dat.2011_15$PWGTP)
sum(df.acs.ipw.model2$product.weight.trimmed.rescaled, na.rm = TRUE)

# Rake product weight to population margins for age, sex, race/ethnicity

raked <-
  rake(design = svydesign(id = ~ 1,
                          strata = NULL,
                          weights = ~ product.weight.trimmed.rescaled,
                          data = df.acs.ipw.model2 %>%
                            drop_na(product.weight.trimmed.rescaled)),
       sample.margins = list(~ age,
                             ~ sex,
                             ~ c_race_eth),
       population.margins = list(acssub %>%
                                 group_by(age) %>%
                                 summarise(Freq = sum(PWGTP)),
                                 acssub %>%
                                 group_by(sex) %>%
                                 summarise(Freq = sum(PWGTP)),
                                 acssub %>%
                                 group_by(c_race_eth) %>%
                                 summarise(Freq = sum(PWGTP))))

df.acs.ipw.model2 <- df.acs.ipw.model2 %>%
  left_join(data.frame(src_subject_id = raked$variables$src_subject_id,
                       product.weight.trimmed.rescaled.raked = weights(raked)))

# ------------------------------------------------------------------------------
# Check how well the weighting worked

# Compare the means in:
# - unweighted full sample
# - weighted full sampmle
# - unweighted subsample
# - weighted subsample
# - cf. those in ACS per Heeringa et al. (2020) arxiv
# ------------------------------------------------------------------------------

# The .variables are multilevel factors, so in order to look at means we need
# to first convert into a series of dummy variables.

df.acs.ipw.model2.dummied <- df.acs.ipw.model2 %>%
  fastDummies::dummy_cols(select_columns = vars.acs.weightmodel)

# We also need a list of the names of the new dummy variables

vars.acs.weightmodel.dummied <- setdiff(names(df.acs.ipw.model2.dummied),
                                        names(df.acs.ipw.model2))

# Now calculate means for comparison

df.acs.ipw.model2.dummied %>%
  mutate(group = "fullsample") %>%
  # append rows for subsample
  bind_rows(df.acs.ipw.model2.dummied %>%
              filter(in.subset == 1) %>%
              mutate(group = "subsample")) %>%
  # ...
  pivot_longer(cols = all_of(vars.acs.weightmodel.dummied),
               names_to = "variable",
               values_to = "value") %>%
  group_by(group, variable) %>%
  summarise(unweighted = mean(value,
                              na.rm = TRUE),
            weighted = Hmisc::wtd.mean(value,
                                       weights = product.weight.trimmed.rescaled.raked,
                                       na.rm = TRUE)) %>%
  # wrangle
  pivot_longer(cols = c(unweighted,
                        weighted),
               names_to = "metric",
               values_to = "value") %>%
  unite("colname", group, metric, sep = "_") %>%
  pivot_wider(names_from = "colname",
              values_from = "value") %>%
  mutate_if(is.numeric,
            ~ round(.x, 2)) %>%
  as.data.frame()

# Write out your weights

df.acs.ipw.model2 %>%
  select(src_subject_id,
         ipweight = product.weight.trimmed.rescaled.raked) %>%
  write_csv("new-weights.csv")
