# ------------------------------------------------------------------------------
# Read in data and do some renaming as necessary to match existing code
# in ABCDPropWeight_V1_R.R
# ------------------------------------------------------------------------------

dat.1 <- read_tsv("pdem02.txt",
                  col_names = FALSE,
                  skip = 2,
                  guess_max = 1e5) %>%
  set_names(read_tsv("pdem02.txt",
                     col_names = TRUE,
                     n_max = 0) %>%
              names()) %>%
  # append age, site
  left_join(read_tsv("abcd_lt01.txt",
                     col_names = FALSE,
                     skip = 2,
                     guess_max = 1e5) %>%
              set_names(read_tsv("abcd_lt01.txt",
                                 col_names = TRUE,
                                 n_max = 0) %>%
                          names()) %>%
              filter(eventname == "baseline_year_1_arm_1") %>%
              mutate(site_name = case_when(site_id_l == 'site01' ~ 'CHLA',
                                           site_id_l == 'site02' ~ 'CUB',
                                           site_id_l == 'site03' ~ 'FIU',
                                           site_id_l == 'site04' ~ 'LIBR',
                                           site_id_l == 'site05' ~ 'MUSC',
                                           site_id_l == 'site06' ~ 'OHSU',
                                           site_id_l == 'site07' ~ 'ROC',
                                           site_id_l == 'site08' ~ 'SRI',
                                           site_id_l == 'site09' ~ 'UCLA',
                                           site_id_l == 'site10' ~ 'UCSD',
                                           site_id_l == 'site11' ~ 'UFL',
                                           site_id_l == 'site12' ~ 'UMB',
                                           site_id_l == 'site13' ~ 'UMICH',
                                           site_id_l == 'site14' ~ 'UMN',
                                           site_id_l == 'site15' ~ 'UPMC',
                                           site_id_l == 'site16' ~ 'UTAH',
                                           site_id_l == 'site17' ~ 'UVM',
                                           site_id_l == 'site18' ~ 'UWM',
                                           site_id_l == 'site19' ~ 'VCU',
                                           site_id_l == 'site20' ~ 'WUSTL',
                                           site_id_l == 'site21' ~ 'YALE',
                                           site_id_l == 'site22' ~ 'MSSM')) %>%
              select(src_subject_id,
                     tlfb_age_calc_inmonths_l = interview_age,
                     site_name))

dat.2 <- read_tsv("acspsw03.txt",
                  col_names = FALSE,
                  skip = 2,
                  guess_max = 1e5) %>%
  set_names(read_tsv("acspsw03.txt",
                     col_names = TRUE,
                     n_max = 0) %>%
              names()) %>%
  # append site
  left_join(dat.1 %>%
              select(src_subject_id,
                     site_name))

# NOTE THIS FILE IS NOT IN 3.0 RELEASE

dat.2011_15 <- readRDS("ACS2011_15_I.Rds") %>%
  rename(src_subject_id = id_redcap)


# ------------------------------------------------------------------------------
# ... continue, minimally modifying the code from ABCDPropWeight_V1_R.R
#     to work with 3.0 release data
# ------------------------------------------------------------------------------

dat.demo=dat.1[dat.1$eventname == "baseline_year_1_arm_1",]
dim(dat.demo)

dat.acs = dat.2[dat.2$eventname == "baseline_year_1_arm_1",]
nrow(dat.acs)

#Demographic
selected.vars=c("tlfb_age_calc_inmonths_l","demo_sex_v2","demo_race_a_p___10","demo_race_a_p___11","demo_race_a_p___12","demo_race_a_p___13","demo_race_a_p___14","demo_race_a_p___15","demo_race_a_p___16","demo_race_a_p___17","demo_race_a_p___18","demo_race_a_p___19","demo_race_a_p___20","demo_race_a_p___21","demo_race_a_p___22","demo_race_a_p___23","demo_race_a_p___24","demo_race_a_p___25","demo_comb_income_v2","demo_prnt_marital_v2","demo_roster_v2","demo_prnt_empl_v2","demo_prtnr_empl_v2","demo_prnt_gender_id_v2","demo_ethn_v2","demo_race_a_p___99","demo_race_a_p___77")
newdemo=dat.demo[,c("src_subject_id","site_name",selected.vars)]
nrow(newdemo)

# set 777 and 999 to NA, a number of selected variables have these missing data codes
newdemo[newdemo==999|newdemo==777]=NA
newdemo[,selected.vars]=sapply(newdemo[,selected.vars],as.numeric)

# descriptive for age in months
summary(newdemo$tlfb_age_calc_inmonths_l)

# divide by 12
newdemo$age1 <- (newdemo$tlfb_age_calc_inmonths_l)/12
summary(newdemo$age1)

# as integer
newdemo$age <- as.integer(newdemo$age1)
table(newdemo$age, exclude=NULL)

# set those > 10 to 10 and 8 to 9 for integer age
newdemo$age=newdemo$age
newdemo$age [newdemo$age > 10] <- 10
newdemo$age [newdemo$age ==8] <- 9
table(newdemo$age, exclude=NULL)

# recode sex and intersex
newdemo$sex <- 1
newdemo$sex [newdemo$demo_sex_v2==2 | newdemo$demo_sex_v2==4] <- 2
newdemo$sex [newdemo$demo_sex_v2==6] <- NA
table(newdemo$sex, exclude= NULL)

# race/ethnicity
# create dummys first
newdemo$white <- 0
newdemo$white [newdemo$demo_race_a_p___10==1] <- 1
table(newdemo$white, newdemo$demo_race_a_p___10, exclude=NULL)

# black
newdemo$blk <- 0
newdemo$blk [newdemo$demo_race_a_p___11==1] <- 1
table(newdemo$blk)

# asian
newdemo$asian <- 0
newdemo$asian [newdemo$demo_race_a_p___18==1 | newdemo$demo_race_a_p___19==1 |
                 newdemo$demo_race_a_p___20==1 | newdemo$demo_race_a_p___21==1 | newdemo$demo_race_a_p___22==1
               | newdemo$demo_race_a_p___23==1 | newdemo$demo_race_a_p___24==1  ] <- 1
table(newdemo$asian)

# aian
newdemo$aian <- 0
newdemo$aian [newdemo$demo_race_a_p___12==1 | newdemo$demo_race_a_p___13==1] <- 1
table(newdemo$aian)

# nhpi
newdemo$nhpi <- 0
newdemo$nhpi [newdemo$demo_race_a_p___14==1 | newdemo$demo_race_a_p___15==1
              | newdemo$demo_race_a_p___16==1 | newdemo$demo_race_a_p___17==1] <- 1
table(newdemo$nhpi)

#other
newdemo$oth <- 0
newdemo$oth [newdemo$demo_race_a_p___25==1 ] <-1
table(newdemo$oth)

# race counts with certain groups set to 1 only (asian aian nhpi)
newdemo$racecount2 <- (newdemo$white + newdemo$blk + newdemo$asian + newdemo$aian + newdemo$nhpi+ newdemo$oth)
table(newdemo$racecount2)

# indicator of mixed race
newdemo$mixed1 <- NA
newdemo$mixed1 [newdemo$racecount2 <=1]  <- 0
newdemo$mixed1 [newdemo$racecount2 > 1] <- 1
table (newdemo$mixed1)

# use coding as in SAS, assign in this order to match SH
newdemo$race_eth<-NA;
newdemo$race_eth [newdemo$demo_race_a_p___10==1 ] <- 1
newdemo$race_eth [newdemo$demo_race_a_p___11==1 ] <- 2
newdemo$race_eth [newdemo$demo_race_a_p___12==1 ] <- 5
newdemo$race_eth [newdemo$demo_race_a_p___13==1 ] <- 5
newdemo$race_eth [newdemo$demo_race_a_p___14==1 ] <- 6
newdemo$race_eth [newdemo$demo_race_a_p___15==1 ] <- 6
newdemo$race_eth [newdemo$demo_race_a_p___16==1 ] <- 6
newdemo$race_eth [newdemo$demo_race_a_p___17==1 ] <- 6
newdemo$race_eth [newdemo$demo_race_a_p___18==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___19==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___20==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___21==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___22==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___23==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___24==1 ] <- 4
newdemo$race_eth [newdemo$demo_race_a_p___25==1 ] <- 8
newdemo$race_eth [newdemo$demo_race_a_p___99==1 | newdemo$demo_race_a_p___77==1] <- NA
newdemo$race_eth [newdemo$mixed1==1]         <- 9

#NOTE: if you downloaded data from NDA released table, use demo_ethn_v2 instead for the following line;
#if you downloaded from data dump, demo_ethn_v2 is fine;
#if you use RDS file, use demo_ethn_p instead
newdemo$race_eth [newdemo$demo_ethn_v2==1] <- 3

table(newdemo$race_eth,exclude=NULL)

# create race pattern variables
# full counts
newdemo$whitecount <- (newdemo$demo_race_a_p___10)
newdemo$blackcount <- (newdemo$demo_race_a_p___11)
newdemo$aiancount <- (newdemo$demo_race_a_p___12 + newdemo$demo_race_a_p___13)
newdemo$nhpicount <- (newdemo$demo_race_a_p___14 +newdemo$demo_race_a_p___15 + newdemo$demo_race_a_p___16
                      + newdemo$demo_race_a_p___17)
newdemo$asiancount <- (newdemo$demo_race_a_p___18 + newdemo$demo_race_a_p___19 + newdemo$demo_race_a_p___20 +
                         newdemo$demo_race_a_p___21 + newdemo$demo_race_a_p___22 + newdemo$demo_race_a_p___23 + newdemo$demo_race_a_p___24)
newdemo$othercount <- newdemo$demo_race_a_p___25
newdemo$racecount <- (newdemo$whitecount+  newdemo$blackcount + newdemo$aiancount + newdemo$nhpicount +
                        newdemo$asiancount + newdemo$othercount)
table(newdemo$racecount, exclude=NULL)

# count variables for pattern #1
newdemo$race_eth_pat <- (100000*newdemo$whitecount + 10000*newdemo$blackcount + 1000*newdemo$asiancount + 100*newdemo$aiancount +
                           10*newdemo$nhpicount + newdemo$othercount)
table(newdemo$race_eth_pat, exclude=NULL)

# dummy variables for pattern #2
newdemo$race_eth_pat2 <- (100000*newdemo$white + 10000*newdemo$blk + 1000*newdemo$asian + 100*newdemo$aian +
                            10*newdemo$nhpi + newdemo$oth)
table(newdemo$race_eth_pat2, exclude=NULL)

# family income
newdemo$faminc <- NA
newdemo$faminc [newdemo$demo_comb_income_v2 %in% 1:4] <- 1
newdemo$faminc [newdemo$demo_comb_income_v2 %in% 5:6] <- 2
newdemo$faminc [newdemo$demo_comb_income_v2 %in% (7)] <- 3
newdemo$faminc [newdemo$demo_comb_income_v2 %in% (8)] <- 4
newdemo$faminc [newdemo$demo_comb_income_v2 %in% (9)] <- 5
newdemo$faminc [newdemo$demo_comb_income_v2 %in% (10)] <- 6
table(newdemo$faminc, exclude= NULL)

# family type
newdemo$famtype <- NA
newdemo$famtype [newdemo$demo_prnt_marital_v2==1 | newdemo$demo_prnt_marital_v2==6] <- 1
newdemo$famtype [newdemo$demo_prnt_marital_v2 %in% 2:5] <- 2
table (newdemo$famtype, exclude = NULL)

# HH size
newdemo$hhsize <- NA
newdemo$hhsize [newdemo$demo_roster_v2 %in% c(0,1,2,3)] <- 1
newdemo$hhsize [newdemo$demo_roster_v2 %in% c(4)] <- 4
newdemo$hhsize [newdemo$demo_roster_v2 %in% c(5)] <- 5
newdemo$hhsize [newdemo$demo_roster_v2 %in% c(6)] <- 6
newdemo$hhsize [newdemo$demo_roster_v2 > 6] <- 7
table (newdemo$hhsize, exclude = NULL)

# Region
newdemo$region <- 3
newdemo$region [newdemo$site_name %in% c("ROC","UPMC","UVM","YALE")] <- 1
newdemo$region [newdemo$site_name %in% c("UMICH","UMN","UWM","WUSTL")] <- 2
newdemo$region [newdemo$site_name %in% c("CHLA","CUB","OHSU","SRI","UCLA","UCSD","UTAH")] <- 4
table (newdemo$region, exclude = NULL)

#########################################################################################
# ACS data set
acs=dat.acs

# keep only key variables
acs_s <- acs[,c("src_subject_id", "rel_family_id", "rel_group_id", "rel_relationship", "rel_same_sex", "site_name")]
acs_s[,2:5]=sapply(acs_s[,2:5],as.numeric)
names(acs_s)
summary(acs_s)

# allmult variable (multiple births)
acs_s$allmult <- 0
acs_s$allmult [acs_s$rel_relationship %in% c(2,3)] <- 1
table(acs_s$allmult)

# twin site variable, note corrected to VCU assignment as twin site (SH)
acs_s$sitetwin <- 0
acs_s$sitetwin [acs_s$site_name %in% c("UMN","CUB","VCU","WUSTL") & acs_s$allmult==1] <- 1
table(acs_s$sitetwin)
str(acs_s)

############################################################################
# merge temp1 saved above and acs_s into tmpmerge
tmpmerge <- merge(newdemo, acs_s, by="src_subject_id")
summary(tmpmerge)
names(tmpmerge)
table(tmpmerge$age, exclude=NULL)

# tables of key variables: 1. one way tables and 2. by single and multiple birth status
# factor vars to add variable labels

# Allmult factor
tmpmerge$allmultc <- factor(tmpmerge$allmult, levels = c(0,1), labels = c("Single Birth", "Multiple Birth"))
table(tmpmerge$allmultc, exclude=NULL)

# Race_Eth Factor
tmpmerge$race_ethc <- factor(tmpmerge$race_eth, levels = c(1,2,3,4,5,6,8,9),
                             labels = c("Non-Hispanic White", "Non-Hispanic Black", "Hispanic", "Asian" ,"AIAN", "NHPI", "OTHER" ,"MULTIPLE"))
table (tmpmerge$race_ethc, exclude=NULL)
table (tmpmerge$race_ethc, tmpmerge$allmultc, exclude=NULL)

# Sex Factor
tmpmerge$sexc <- factor(tmpmerge$sex, levels = c(1,2), labels = c("Male", "Female"))
table (tmpmerge$sexc, exclude=NULL)
table (tmpmerge$sexc, tmpmerge$allmultc, exclude=NULL)

# Family income
tmpmerge$famincc <- factor(tmpmerge$faminc, levels = c(1:6),
                           labels = c("<25k", "25k-49k", "50k-74k", "75k-99k", "100k-199k", "200k+"))
table(tmpmerge$famincc, exclude=NULL)
table(tmpmerge$famincc, tmpmerge$allmultc, exclude=NULL)

# Family type
tmpmerge$famtypec  <- factor(tmpmerge$famtype, levels = c(1:2), labels = c("Married", "Other Family"))
table (tmpmerge$famtypec , exclude=NULL)
table (tmpmerge$famtypec, tmpmerge$allmultc, exclude=NULL)

# Site Twin
tmpmerge$sitetwinc <- factor(tmpmerge$sitetwin, levels = c(0:1), labels = c("General Cohort", "Site Twin Cohort"))
table (tmpmerge$sitetwinc, exclude=NULL)
table (tmpmerge$sitetwinc, tmpmerge$allmultc, exclude=NULL)

# Age
table(tmpmerge$age, exclude=NULL)
table (tmpmerge$age, tmpmerge$allmultc, exclude=NULL)

# Region
table(tmpmerge$region, exclude=NULL)
table (tmpmerge$region, tmpmerge$allmultc, exclude=NULL)

# HH size
table(tmpmerge$hhsize, exclude=NULL)
table (tmpmerge$hhsize, tmpmerge$allmultc, exclude=NULL)

# Site Twin
table(tmpmerge$sitetwin, exclude=NULL)
table (tmpmerge$sitetwin, tmpmerge$allmultc, exclude=NULL)


###############################################################################

# Use site name from first data set site_name.x
tmpmerge$site_name <- tmpmerge$site_name.x
tmpmerge$site_name
names(tmpmerge)

# keep only key variables for imputation
# use names to select
tmpimp <- tmpmerge[c("src_subject_id", "age", "sex", "allmult", "famtype", "faminc", "sitetwin",
                     "hhsize", "race_eth", "rel_relationship", "site_name", "demo_prnt_empl_v2","demo_prtnr_empl_v2",
                     "demo_prnt_gender_id_v2", "region")]
names(tmpimp)

# set some vars to factor for imputation
tmpimp$age=as.factor(tmpimp$age)
tmpimp$hhsize=as.factor(tmpimp$hhsize)
tmpimp$rel_relationship=as.factor(tmpimp$rel_relationship)
tmpimp$region=as.factor(tmpimp$region)
tmpimp$sex=as.factor(tmpimp$sex)
tmpimp$allmult=as.factor(tmpimp$allmult)
tmpimp$famtype=as.factor(tmpimp$famtype)
tmpimp$faminc=as.factor(tmpimp$faminc)
tmpimp$race_eth=as.factor(tmpimp$race_eth)
tmpimp$sitetwin=as.factor(tmpimp$sitetwin)

# set 777 and 999 to NA
tmpimp$demo_prnt_empl_v2 [tmpimp$demo_prnt_empl_v2 == 777 | tmpimp$demo_prnt_empl_v2==999]  <- NA
table(tmpimp$demo_prnt_empl_v2,exclude=NULL)

tmpimp$demo_prtnr_empl_v2 [tmpimp$demo_prtnr_empl_v2==777 | tmpimp$demo_prtnr_empl_v2==999] <- NA
table(tmpimp$demo_prtnr_empl_v2 , exclude=NULL)

tmpimp$demo_prnt_gender_id_v2 [tmpimp$demo_prnt_gender_id_v2==777 | tmpimp$demo_prnt_gender_id_v2==999] <- NA
table(tmpimp$demo_prnt_gender_id_v2 , exclude=NULL)

tmpimp$demo_prnt_empl_v2=as.factor(tmpimp$demo_prnt_empl_v2)
tmpimp$demo_prtnr_empl_v2=as.factor(tmpimp$demo_prtnr_empl_v2)
tmpimp$demo_prnt_gender_id_v2=as.factor(tmpimp$demo_prnt_gender_id_v2)
str(tmpimp)

# begin imputation steps ##############################################################################
# missing data pattern for tmpimp
md.pattern(tmpimp)
summary(tmpimp)

# impute missing data on ager famtype faminc hhsize race_eth demo_prnt_empl_v2 demo_prtnr_empl_v2 demo_prnt_gender_id_v2
init = mice(tmpimp, maxit=0)
meth = init$method
meth

# specify imputation model type, would be ok as is but for clarity
meth[c("faminc", "hhsize", "race_eth", "demo_prnt_empl_v2",
       "demo_prtnr_empl_v2", "demo_prnt_gender_id_v2")]="polyreg"
meth[c("age","famtype")]="logreg"
meth

tmpimpm1 <- mice(tmpimp, m=1, seed=0270, method=meth)
summary(tmpimpm1)

#extract the first imputed data set
longm1 <- complete(tmpimpm1, 1)
summary(longm1)
table(longm1$race_eth, exclude=NULL)

# create fes variable using long imputed data set
longm1$fesabcd [longm1$famtype==1 & longm1$demo_prnt_empl_v2 %in% c(1,2,3,9,10,11) & longm1$demo_prtnr_empl_v2 %in% c(1,2,3,9,10,11)] <- 1
longm1$fesabcd [longm1$famtype==1 & longm1$demo_prnt_empl_v2 %in% c(1,2,3,9,10,11) & longm1$demo_prtnr_empl_v2 %in% c(4,5,6,7,8,12,13,NA)] <- 2
longm1$fesabcd [longm1$famtype==1 & longm1$demo_prnt_empl_v2 %in% c(4,5,6,7,8,12,13,NA) & longm1$demo_prtnr_empl_v2 %in% c(1,2,3,9,10,11)] <- 2
longm1$fesabcd [longm1$famtype==1 & longm1$demo_prnt_empl_v2 %in% c(4,5,6,7,8,12,13,NA) & longm1$demo_prtnr_empl_v2 %in% c(4,5,6,7,8,12,13,NA)] <- 4

longm1$fesabcd [longm1$famtype %in% c(NA,2) & longm1$demo_prnt_empl_v2 %in% c(1,2,3,9,10,11) & longm1$demo_prnt_gender_id_v2==1 ] <- 5
longm1$fesabcd [longm1$famtype %in% c(NA,2) & longm1$demo_prnt_empl_v2 %in% c(4,5,6,7,8,12,NA) & longm1$demo_prnt_gender_id_v2==1 ] <- 6
longm1$fesabcd [longm1$famtype %in% c(NA,2) & longm1$demo_prnt_empl_v2 %in% c(1,2,3,9,10,11) & longm1$demo_prnt_gender_id_v2 %in% c(2,3,4,5,6,7,NA) ] <- 7
longm1$fesabcd [longm1$famtype %in% c(NA,2) & longm1$demo_prnt_empl_v2 %in% c(4,5,6,7,8,12,NA) & longm1$demo_prnt_gender_id_v2 %in% c(2,3,4,5,6,7,NA) ] <- 8
table(longm1$fesabcd, exclude=NULL)

##################################################################################################################
# tables of key variables using imputed data set longm1  (1. one way tables and 2. by single and multiple birth status)
# factor vars to add variable labels

# Fes
longm1$fesc <- factor(longm1$fes, levels = c(1,2,4,5,6,7,8),
                      labels = c("Married, 2 in LF", "Married, 1 in LF", "Married, 0 in LF", "Single HH, M, LF",
                                 "Single HH, M, NLF","Single HH, F, LF", "Single HH, F, NLF"))

table(longm1$fesc, exclude=NULL)
table(longm1$fesc, longm1$famtype, exclude=NULL)
table(longm1$fesc, longm1$demo_prnt_empl_v2, exclude=NULL)
table(longm1$fesc, longm1$demo_prtnr_empl_v2, exclude=NULL)
table(longm1$fesc, longm1$demo_prnt_gender_id_v2, exclude=NULL)

# check imputed variables using factor and labels
# Multiple Birth
longm1$allmultc  <- factor(longm1$allmult, levels = c(0:1), labels = c("Single Birth", "Multiple Birth"))
table (longm1$allmultc, exclude=NULL)

# Race_Eth Factor
longm1$race_ethc <- factor(longm1$race_eth, levels = c(1,2,3,4,5,6,8,9),
                           labels = c("Non-Hispanic White", "Non-Hispanic Black", "Hispanic", "Asian" ,"AIAN", "NHPI", "OTHER" ,"MULTIPLE"))
table (longm1$race_ethc, exclude=NULL)
table (longm1$race_ethc, longm1$allmultc, exclude=NULL)

# Sex Factor
longm1$sexc <- factor(longm1$sex, levels = c(1,2), labels = c("Male", "Female"))
table (longm1$sexc, exclude=NULL)
table (longm1$sexc, longm1$allmultc, exclude=NULL)

# family income
longm1$famincc <- factor(longm1$faminc, levels = c(1:6),
                         labels = c("<25k", "25k-49k", "50k-74k", "75k-99k", "100k-199k", "200k+"))
table (longm1$famincc , exclude=NULL)
table (longm1$famincc, longm1$allmultc, exclude=NULL)

# family type
longm1$famtypec  <- factor(longm1$famtype, levels = c(1:2), labels = c("Married", "Other Family"))
table (longm1$famtypec , exclude=NULL)
table (longm1$famtypec, longm1$allmultc, exclude=NULL)

# fescabcd
table(longm1$fesc, exclude=NULL)
table(longm1$fesc, longm1$allmultc, exclude=NULL)
table (longm1$fesc, longm1$famtypec, exclude=NULL)

# age
table (longm1$age, exclude=NULL)
table (longm1$age, longm1$allmultc, exclude=NULL)

# HH size
longm1$hhsizec  <- factor(longm1$hhsize, levels = c(1,4,5,6,7),
                          labels = c( "2-3 Persons", "4 Persons" ,"5 Persons", "6 Persons", "7 or More Persons"))
table (longm1$hhsizec, exclude=NULL)
table (longm1$hhsizec, longm1$allmultc, exclude=NULL)

# site twin
longm1$sitetwinc <- factor(longm1$sitetwin, levels = c(0:1), labels = c("General Cohort", "Site Twin Cohort"))
table (longm1$sitetwinc, exclude=NULL)
table (longm1$sitetwinc, longm1$allmultc, exclude=NULL)

# rel_relationship
longm1$rel_relationshipc <- factor(longm1$rel_relationship, levels = c(0,1,2,3), labels = c("Singleton", "Sibling", "Twin","Triplet"))
table (longm1$rel_relationshipc, exclude=NULL)
table (longm1$rel_relationshipc, longm1$allmultc, exclude=NULL)

# create a acsflag =0 variable
longm1$acsflag <- 0
summary(longm1)

saveRDS(longm1, file = "Jan_2019abcd_i.Rds")
new_test <- readRDS("Jan_2019abcd_i.Rds")
names(new_test)
summary(new_test)

#################################
# ACS_ABCD_Poolweight

library(haven)
acs11_15_i  <-dat.2011_15

# add 2 new variables to match abcd_oct18_i
acs11_15_i$demo_prtnr_empl_v2 <- NA
acs11_15_i$rel_relationship <- NA
acs11_15_i$sitetwin <- NA

names(acs11_15_i)
summary(acs11_15_i)
str(acs11_15_i)

abcd_nov18_i  <- readRDS("Jan_2019abcd_i.Rds")
summary(abcd_nov18_i)

# add PWGTP to abcd_nov18_i and subset to variables in ACS data for concatenation
abcd_nov18_i$PWGTP <- NA

abcd_nov18_i_s <- abcd_nov18_i[c("PWGTP", "age", "sex", "region", "race_eth","faminc", "famtype",
                                 "hhsize","allmult","src_subject_id", "site_name", "fesabcd", "acsflag", "demo_prtnr_empl_v2", "rel_relationship", "sitetwin")]
names(abcd_nov18_i_s)
summary(abcd_nov18_i_s)
str(abcd_nov18_i_s)

# stack ACS and ABCD data sets using rbind (row bind)
nov2018_acs_abcd_i <- rbind(acs11_15_i, abcd_nov18_i_s)
names(nov2018_acs_abcd_i)
head(nov2018_acs_abcd_i)
summary(nov2018_acs_abcd_i)

# recode vars for logistic models
# age
table(nov2018_acs_abcd_i$age, exclude=NULL)
table(nov2018_acs_abcd_i$age, nov2018_acs_abcd_i$acsflag, exclude=NULL)

# fesabcd
nov2018_acs_abcd_i$c_fesabcd <- nov2018_acs_abcd_i$fesabcd
nov2018_acs_abcd_i$c_fesabcd [nov2018_acs_abcd_i$fesabcd %in% c(5,7)] <- 5
nov2018_acs_abcd_i$c_fesabcd [nov2018_acs_abcd_i$fesabcd %in% c(6,8)] <- 6
table(nov2018_acs_abcd_i$c_fesabcd, nov2018_acs_abcd_i$acsflag, exclude =NULL)

# c_race_eth
nov2018_acs_abcd_i$c_race_eth <- nov2018_acs_abcd_i$race_eth
nov2018_acs_abcd_i$c_race_eth [nov2018_acs_abcd_i$race_eth %in% c(4,5,6,8)] <- 4
table(nov2018_acs_abcd_i$c_race_eth,nov2018_acs_abcd_i$acsflag, exclude =NULL)

# weight for method 1
nov2018_acs_abcd_i$meth1wgt = nov2018_acs_abcd_i$PWGTP
nov2018_acs_abcd_i$meth1wgt [nov2018_acs_abcd_i$acsflag==0] <- 1
summary(nov2018_acs_abcd_i$meth1wgt, exclude = NULL)

# create factor versions of variables
# Multiple Birth
nov2018_acs_abcd_i$allmultc  <- factor(nov2018_acs_abcd_i$allmult, levels = c(0:1), labels = c("Single Birth", "Multiple Birth"))
table (nov2018_acs_abcd_i$allmultc, exclude=NULL)

# Race_Eth Factor
nov2018_acs_abcd_i$race_ethc <- factor(nov2018_acs_abcd_i$race_eth, levels = c(1,2,3,4,5,6,8,9),
                                       labels = c("Non-Hispanic White", "Non-Hispanic Black", "Hispanic", "Asian" ,"AIAN", "NHPI", "OTHER" ,"MULTIPLE"))
table (nov2018_acs_abcd_i$race_ethc, exclude=NULL)

# Collapsed Race Eth
nov2018_acs_abcd_i$c_race_ethc <- factor(nov2018_acs_abcd_i$c_race_eth, levels = c(1,2,3,4,9),
                                         labels = c("Non-Hispanic White", "Non-Hispanic Black", "Hispanic", "Asian AIAN NHPI OTHER" ,"MULTIPLE"))
table (nov2018_acs_abcd_i$c_race_ethc, exclude=NULL)

# Sex Factor
nov2018_acs_abcd_i$sexc <- factor(nov2018_acs_abcd_i$sex, levels = c(1,2), labels = c("Male", "Female"))
table (nov2018_acs_abcd_i$sexc, exclude=NULL)

# Family income
nov2018_acs_abcd_i$famincc <- factor(nov2018_acs_abcd_i$faminc, levels = c(1:6),
                                     labels = c("<25k", "25k-49k", "50k-74k", "75k-99k", "100k-199k", "200k+"))
table (nov2018_acs_abcd_i$famincc , exclude=NULL)

# Family type
nov2018_acs_abcd_i$famtypec  <- factor(nov2018_acs_abcd_i$famtype, levels = c(1:2), labels = c("Married", "Other Family"))
table (nov2018_acs_abcd_i$famtypec , exclude=NULL)

# age
nov2018_acs_abcd_i$age= as.factor(nov2018_acs_abcd_i$age)
table (nov2018_acs_abcd_i$age, exclude=NULL)

# HH size
nov2018_acs_abcd_i$hhsizec  <- factor(nov2018_acs_abcd_i$hhsize, levels = c(1,4,5,6,7),
                                      labels = c( "2-3 Persons", "4 Persons" ,"5 Persons", "6 Persons", "7 or More Persons"))
table (nov2018_acs_abcd_i$hhsizec, exclude=NULL)

# site twin
nov2018_acs_abcd_i$sitetwinc <- factor(nov2018_acs_abcd_i$sitetwin, levels = c(0:1),
                                       labels = c("General Cohort", "Site Twin Cohort"))
table (nov2018_acs_abcd_i$sitetwinc, exclude=NULL)

# rel_relationship
nov2018_acs_abcd_i$rel_relationshipc <- factor(nov2018_acs_abcd_i$rel_relationship, levels = c(0,1,2,3), labels = c("Singleton", "Sibling", "Twin","Triplet"))
table (nov2018_acs_abcd_i$rel_relationshipc, exclude=NULL)

# fesabcd
nov2018_acs_abcd_i$c_fesabcdc <- factor(nov2018_acs_abcd_i$c_fesabcd, levels = c(1,2,4,5,6),
                                        labels = c("Married,2 in LF", "Married, 1 in LF", "Married, 0 in LF","Single HH, LF", "Single HH, NLF"))
table (nov2018_acs_abcd_i$c_fesabcdc, exclude=NULL)

# region
nov2018_acs_abcd_i$regionc <- factor(nov2018_acs_abcd_i$region, levels = c(1,2,3,4),
                                     labels = c("Northeast" ,"MidWest", "South", "West"))
table (nov2018_acs_abcd_i$regionc, exclude=NULL)

# tables of key vars by acsflag, with labels
table (nov2018_acs_abcd_i$age, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$famincc, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$famtypec, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$c_fesabcdc, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$hhsizec, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$race_ethc, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$c_race_ethc, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$regionc, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$sexc, nov2018_acs_abcd_i$acsflag, exclude=NULL)
table (nov2018_acs_abcd_i$site_name, nov2018_acs_abcd_i$acsflag, exclude=NULL)

##########################################################################################
# Models for weight preparation

# Model 1 Propensity for Method 1 Weight

m1fit1 <- glm(relevel(factor(acsflag),ref='1') ~ I(age==9)
              + relevel(factor(faminc),ref='6')
              + relevel(factor(famtype),ref='2')
              + relevel(factor(c_fesabcd),ref='6')
              + relevel(factor(hhsize),ref='7')
              + relevel(factor(c_race_eth),ref='9')
              + relevel(factor(region),ref='4')
              + relevel(factor(sex),ref='2'),
              data=nov2018_acs_abcd_i, family=quasibinomial(), weights=meth1wgt)
summary(m1fit1)

# create new variables
nov2018_acs_abcd_i$propmeth1 = predict(m1fit1, type="response")
names(nov2018_acs_abcd_i)
summary(nov2018_acs_abcd_i$propmeth1)

# assign different weight values depending on acsflag status
nov2018_acs_abcd_i$pwgtmeth1=1/nov2018_acs_abcd_i$propmeth1
summary(nov2018_acs_abcd_i$pwgtmeth1)

nov2018_acs_abcd_i$pwgtmeth1 <- ifelse(nov2018_acs_abcd_i$acsflag %in% (1),
                                       nov2018_acs_abcd_i$PWGTP, nov2018_acs_abcd_i$pwgtmeth1)
summary(nov2018_acs_abcd_i$pwgtmeth1)

# by group of acsflag
# acsflag==1
acssub <- subset(nov2018_acs_abcd_i,acsflag==1)

# acsflag==0
abcdsub <- subset(nov2018_acs_abcd_i,acsflag==0)

# ------------------------------------------------------------------------------
#  -- STOP following ABCDPropWeight_V1_R.R --
# ------------------------------------------------------------------------------

# Goal was to reproduce the dataframe used when fitting the propensity model for
# the acs_raked_propensity_score weight using data in the 3.0 release plus the
# ACS2011_15_I.Rds file.

# Have we succeeded?

nrow(nov2018_acs_abcd_i)
nobs(m1fit1)
